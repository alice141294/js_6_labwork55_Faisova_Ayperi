import React, {Component} from 'react';
import AddIngridients from './component/AddIngrigientsToBurger/AddIngridients';
import './App.css';

class App extends Component {
  state = {
    
    ingredients: [
      
      {name: 'Meat', count: 0},
      {name: 'Cheese', count: 0},
      {name: 'Salad', count: 0},
      {name: 'Beacon', count: 0},
      
    ],
    totalPrice: 20
    
  }
  addNewIngridient = (elem) => {
    const ingredients = [...this.state.ingredients];
    let totalPrice = this.state.totalPrices
    const index = ingredients.findIndex(i => i.name === elem.name)
    ingredients[index].count ++;
    totalPrice += elem.price;
    this.setState({totalPrice, ingredients});


  }

  render(){
    return (
      <div className="App">
        <AddIngridients
        oneIngredient = {this.state.ingredients}
        addNewIngridient = {this.addNewIngridient}
        />
      </div>
      )
    }
    
  }
  
  export default App;
  